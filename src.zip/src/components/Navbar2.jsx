import React from 'react'
import { Button } from './ui/button'

const Navbar2 = () => {
    <nav>
        <div>
            <img src="https://www.mediatechtemple.com/" alt="" />
        </div>
        <div>
            <ul>
                <li>Home</li>
                <li>About us</li>
    {/* Carry on  */}
            </ul>
            <Button>Login</Button>
        </div>
    </nav>
}

export default Navbar2
