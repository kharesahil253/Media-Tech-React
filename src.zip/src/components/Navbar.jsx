import { HiDotsVertical } from "react-icons/hi";
import { Link } from "react-router-dom";

const navbaroptions = [
  { link: "home", tex: "Home" },
  { link: "about", tex: "About Us" },
  { link: "product&services", tex: "Product & Services" },
  { link: "ourventures", tex: "Our Ventures" },
  { link: "clients", tex: "Clients" },
  { link: "career", tex: "Career" },
  { link: "contactus", tex: "Contact Us" },
];

const Navbar = () => {
  return (
    <nav className="w-full p-4 bg-white shadow-md fixed top-0 left-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col md:flex-row items-center justify-between">
        {/* Logo */}
        <div className="mb-3 md:mb-0">
          <img
            src="https://www.mediatechtemple.com/wp-content/uploads/2023/09/mtt-5-1.png"
            alt="Media Tech Temple"
            className="h-10 w-auto"
          />
        </div>

        {/* Nav Links */}
        <div className="flex flex-wrap justify-center md:justify-start gap-4 text-sm font-medium text-gray-700">
          {navbaroptions.map((item) => (
            <Link
              key={item.link}
              to={`/${item.link}`}
              className="hover:text-indigo-600 transition-colors"
            >
              {item.tex}
            </Link>
          ))}
        </div>

        {/* Right side: Call & Icon */}
        <div className="flex items-center gap-3 mt-3 md:mt-0">
          <h4 className="text-sm font-semibold text-blue-700">Call Us: 7220867768</h4>
          <HiDotsVertical size={22} className="text-gray-600" />
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
