import React from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

const Tag = () => {
  return (
    <section className="flex justify-center items-center min-h-screen bg-gradient-to-r from-indigo-900 to-blue-800 px-4">
      <Card className="w-full max-w-2xl rounded-xl shadow-lg p-6 bg-white h-96">
        <CardHeader className="text-center">
          <CardTitle className="text-xs font-bold text-gray-800 uppercase">
            Contact Us
          </CardTitle>
          <CardDescription className="text-2xl font-semibold text-blue-950">
            Feel Free to Contact Us
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
              
              </label>
              <Input
                placeholder="  Your Name*"
                type={Text}
                className="border-b-violet-700"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
              </label>
              <Input
                placeholder="Email*"
                className="border-b border-purple-500 rounded-none focus-visible:ring-0 focus-visible:border-purple-600"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
               
              </label>
              <Input
                placeholder="Phone"
                type={Number}
                className="border-b border-purple-500 rounded-none focus-visible:ring-0 focus-visible:border-purple-600"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
               
              </label>
              <Input
                placeholder=" Type your Query*"
                type={Text}
                className="border-b border-purple-500 rounded-none focus-visible:ring-0 focus-visible:border-purple-600"
              />
            </div>
          </form>
        </CardContent>

        <CardFooter className="mt-6">
          <Button
            className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-semibold px-6 py-2 rounded-md hover:opacity-90"
            type="submit"
          >
            Submit
          </Button>
        </CardFooter>
      </Card>
    </section>
  );
};

export default Tag;
