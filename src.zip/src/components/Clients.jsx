import React from "react";

const Clients = () => {
  const images = [
    {
      img: "https://www.mediatechtemple.com/wp-content/uploads/2023/09/Mahindra-logo.png",
    },
    {
      img: "https://www.mediatechtemple.com/wp-content/uploads/2023/09/TVS-motors-logo.png",
    },
    {
      img: "https://www.mediatechtemple.com/wp-content/uploads/2023/09/Hero-logo.png",
    },
    {
      img: "https://www.mediatechtemple.com/wp-content/uploads/2023/09/INSYNC-removebg-preview.png",
    },
  ];
  return (
  <section className="py-16 bg-white text-center">
      <h2 className="text-3xl font-bold text-gray-800 mb-8">Our Clients</h2>
      
      <div className="flex flex-wrap justify-center items-center gap-40">
        {images.map((item, index) => (
          <img
            key={index}
            className="h-20 object-contain hover:scale-105 transition-transform duration-300"
            src={item.img}
            alt={`client-${index}`}
          />
        ))}
      </div>
    </section>
  );
};

export default Clients;
