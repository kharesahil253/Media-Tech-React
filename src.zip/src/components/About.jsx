import React from "react";
import Navbar2 from "./Navbar2";

const About = () => {
  return (
    <section className="bg-white text-gray-800 px-6 py-12 max-w-6xl mx-auto">
      <Navbar2/>
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold mb-4">About Us</h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          MediaTechTemple is a technology-driven company focusing on both
          traditional and innovative solutions. We provide integrated IT
          solutions, marketing, tele-solutions, and advertising services.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-10 items-center">
        <div>
          <img
            src="https://www.mediatechtemple.com/wp-content/uploads/2023/10/shutterstock_93821116.jpg"
            alt="Team"
            className="rounded-xl shadow-md w-full h-auto"
          />
        </div>
        <div>
          <h2 className="text-2xl font-semibold mb-4">Who We Are</h2>
          <p className="text-gray-700 leading-relaxed">
            We are a client-focused team delivering custom software and scalable
            solutions. From government campaigns to private sector innovations,
            our team ensures results by blending technology with creativity.
          </p>
        </div>
      </div>

      <div className="flex">
        <div className="mt-16">
          <h2 className="text-2xl font-semibold mb-4 text-center">
            Our Vision & Mission
          </h2>
          <p className="text-gray-700 text-center max-w-3xl mx-auto">
            At MediaTechTemple, our mission is to empower organizations with the
            tools and strategy they need to succeed in the digital world. We
            strive to lead with integrity, creativity, and excellence.
          </p>
        </div>
        <div>
          <img
            src="https://www.mediatechtemple.com/wp-content/uploads/2019/09/home_img-03.png"
            alt=""
          />
        </div>
      </div>
    </section>
  );
};

export default About;
